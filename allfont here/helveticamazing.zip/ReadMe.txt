Hello font user,
	
Please note that this font is free for personal use ONLY.  

Currently, you may not use the font under any for-profit circumstance.  

In order to use the font commercially, you must purchase a commercial license.  

A license can be purchased at my website - http://jakeluedecke.weebly.com/store/c1/Featured_Products.html

Thank you,
Jake Luedecke
